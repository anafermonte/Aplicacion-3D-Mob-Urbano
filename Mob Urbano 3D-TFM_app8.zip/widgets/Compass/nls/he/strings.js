define({
  "_widgetLabel": "מצפן"
});