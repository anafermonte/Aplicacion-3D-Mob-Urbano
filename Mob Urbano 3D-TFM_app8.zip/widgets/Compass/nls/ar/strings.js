define({
  "_widgetLabel": "بوصلة"
});