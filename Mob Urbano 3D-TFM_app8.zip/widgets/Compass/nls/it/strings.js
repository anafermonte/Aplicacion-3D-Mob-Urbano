define({
  "_widgetLabel": "Bussola"
});