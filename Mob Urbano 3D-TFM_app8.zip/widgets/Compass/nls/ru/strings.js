define({
  "_widgetLabel": "Компас"
});