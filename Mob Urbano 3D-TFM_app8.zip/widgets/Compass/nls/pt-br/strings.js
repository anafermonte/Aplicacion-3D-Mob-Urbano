define({
  "_widgetLabel": "Bússola"
});