define({
  root: ({
    _themeLabel: "Numancia Theme",
    _layout_default: "Default layout",
    _layout_layout1: "Layout 1"
  }),
  "es": 1,
});
