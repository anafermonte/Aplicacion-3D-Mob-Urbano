define({
  "group": "Nome",
  "openAll": "Abrir todos em um painel",
  "dropDown": "Mostrar no menu suspenso",
  "noGroup": "Não há grupo de widget configurado.",
  "groupSetLabel": "Configurar propriedades de grupos do widget"
});