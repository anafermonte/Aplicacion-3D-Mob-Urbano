define({
  "group": "Nume",
  "openAll": "Deschidere toate într-un singur panou",
  "dropDown": "Afişare în meniu derulant",
  "noGroup": "Nu este setat niciun grup de widgeturi.",
  "groupSetLabel": "Setare proprietăţi pentru grupuri de widgeturi"
});