define({
  "group": "Nazwa",
  "openAll": "Otwórz wszystko w jednym panelu",
  "dropDown": "Pokaż w menu rozwijanym",
  "noGroup": "Brak skonfigurowanej grupy widżetów",
  "groupSetLabel": "Skonfiguruj właściwości grupy widżetów"
});