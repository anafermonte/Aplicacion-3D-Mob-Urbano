define({
  "group": "Name",
  "openAll": "Alle in einem Bereich öffnen",
  "dropDown": "In Drop-down-Menü anzeigen",
  "noGroup": "Es wurde keine Widget-Gruppe festgelegt.",
  "groupSetLabel": "Eigenschaften für Widget-Gruppen festlegen"
});