define({
  "group": "Név",
  "openAll": "Összes megnyitása egy panelen",
  "dropDown": "Megjelenítés lenyíló menüsorban",
  "noGroup": "Nincs beállítva widgetcsoport.",
  "groupSetLabel": "Widgetcsoportok tulajdonságainak beállítása"
});