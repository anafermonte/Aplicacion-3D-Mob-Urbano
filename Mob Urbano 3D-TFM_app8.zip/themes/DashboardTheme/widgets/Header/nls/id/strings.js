define({
  "_widgetLabel": "Header",
  "signin": "Masuk",
  "signout": "Keluar",
  "about": "Tentang",
  "signInTo": "Masuk ke",
  "cantSignOutTip": "Fungsi ini tidak tersedia di fungsi pratinjau."
});