define({
  "_widgetLabel": "Otsikkorivi",
  "signin": "Kirjaudu sisään",
  "signout": "Kirjaudu ulos",
  "about": "Tietoja",
  "signInTo": "Kirjaudu palveluun",
  "cantSignOutTip": "Tämä toiminto ei ole käytettävissä esikatselutilassa."
});