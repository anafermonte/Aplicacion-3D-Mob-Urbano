define({
  "_widgetLabel": "En-tête",
  "signin": "Connexion",
  "signout": "Déconnexion",
  "about": "A propos",
  "signInTo": "Se connecter à",
  "cantSignOutTip": "Cette fonction n’est pas disponible en mode d’aperçu."
});