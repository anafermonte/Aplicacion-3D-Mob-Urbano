define({
  "_widgetLabel": "Overskrift",
  "signin": "Log ind",
  "signout": "Log ud",
  "about": "Om",
  "signInTo": "Log ind på",
  "cantSignOutTip": "Denne funktion er ikke tilgængelig i forhåndsvisningen."
});