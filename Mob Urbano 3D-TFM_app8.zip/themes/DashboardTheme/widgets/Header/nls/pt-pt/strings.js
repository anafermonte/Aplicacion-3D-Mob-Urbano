define({
  "_widgetLabel": "Cabeçalho",
  "signin": "Iniciar sessão",
  "signout": "Terminar Sessão",
  "about": "Sobre",
  "signInTo": "Iniciar sessão em",
  "cantSignOutTip": "Esta função não se encontra disponível no modo de pré-visualização."
});