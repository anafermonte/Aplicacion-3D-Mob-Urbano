define({
  "_widgetLabel": "Đầu mục",
  "signin": "Đăng nhập",
  "signout": "Đăng xuất",
  "about": "Về",
  "signInTo": "Đăng nhập vào",
  "cantSignOutTip": "Chức năng này không khả dụng ở chế độ xem trước."
});