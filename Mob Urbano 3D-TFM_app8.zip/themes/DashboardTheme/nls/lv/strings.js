define({
  "_themeLabel": "Vadības paneļa motīvs",
  "_layout_default": "Noklusējuma izkārtojums",
  "_layout_right": "Pareizais izkārtojums"
});