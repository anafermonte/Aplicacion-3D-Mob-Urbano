define({
  "_themeLabel": "Motiv řídicího panelu",
  "_layout_default": "Výchozí rozvržení",
  "_layout_right": "Pravé rozvržení"
});