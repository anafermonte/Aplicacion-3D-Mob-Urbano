define({
  "_themeLabel": "Dashbordtema",
  "_layout_default": "Standardoppsett",
  "_layout_right": "Høyre-oppsett"
});